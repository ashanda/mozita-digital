=== Themesflat Addons For Elementor ===
Tags: addons, elementor, elementor addon, themesflat, widget
Contributors: themesflatc2
Requires at least: 4.9
Tested up to: 5.7
Requires PHP: 5.2
Stable tag: 1.65
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

<p>Themesflat addon for Elementor Page Builder. With 03 of the most popular and add added some widget not available on Elementor Free that you need for everyday use in the website page building.</p>

<p>Specifically, Themesflat addon focuses on support for the author build Template Kits for sale at <a href="https://1.envato.market/o15oE">Template Kits Elementor</a> all in one. Just download only 1 plugin Themesflat Addon
You will have the full wdiget build kit export, import display results as demo link</p>
<h3>Themesflat Addons for Elementor – Features</h3>
<ol>
<li><a href="https://themesflat-addons.com/tf-imagebox-addons-for-elementor/" target="_blank">Image Box</a>: TF ImageBox Addon allow insert images in your site with cool and interactive hover effects in a simple and flexible way. This Addons adds new elements/widgets to Elementor Page Builder. It helps you to easily design the perfect ImageBox for website use Elementor.</li>

<li><a href="https://themesflat-addons.com/tfcarousel-box-addons-for-elementor/" target="_blank">Carousel box</a>: You are looking for carousel addons for the element in Page buider Elementor as IconBox, Gallery, Portfolio, Team Member, Testimonials … Tfcarousel is the most perfect choice. With Tfcarousel you can put everything in a carousel slide. Just design the template in Elementor, Then create a slide and include template.</li>

<li><a href="https://themesflat-addons.com/eslider-demo/" target="_blank">E Slider</a>: Customize Every Part of Your Slider, Elementor was built for you. Create stunning slider, Show an animated sequence of images, videos or other content. Video Sliders, Scrolling Slider, Type Slider </li>

</ol>



== Frequently Asked Questions ==

= Can I use the plugin without Elementor Page Builder? =

No. You cannot use without Elementor since it's an addon for Elementor.

= Does it work with any theme? =

Absolutely! It will work with any theme where Elementor works.

== Screenshots ==

1. Image Box Widget Demo (screenshot-1.png)
2. Carousel Box widget (screenshot-2.png)
Note that the screenshot is stored in the /screenshots.

== Changelog ==

= 1.0.1 - 08/07/2020 =
= 1.0.0 - 20/07/2020 =

Initial stable realese

== Upgrade Notice ==
